
function Save() {
    {
  var x = confirm("Are you sure you want to save?");
  if (x){
      return true;
  }else
    return false;
}

}
function Cancel() {
    confirm("Are you absolutely sure you want to cancel?");
}
function Reset() {
    confirm("Are you absolutely sure you want to reset?");
}
function Delete() {
    {
  var x = confirm("Are you sure you want to delete?");
  if (x){
      return true;
  }else
    return false;
}
}
function Edit() {
    confirm("Are you absolutely sure you want to edit?");
}
function Update() {
    confirm("Are you absolutely sure you want to update?");
}
function Logout() {
    confirm("Are you absolutely sure you want to logout?");
}
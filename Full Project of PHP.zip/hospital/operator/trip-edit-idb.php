<div id="page-wrapper">
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
                <h1 class="page-head-line">Trip-edit</h1>
                <a href="master.php?o=trip-new"><i class="btn btn-success fa fa-pencil"> New Entry</i></a>
                <a href="master.php?o=trip-view"><i class="btn btn-success fa fa-file"> View</i></a>
                <a href="master.php"><i onclick="Cancel()" class="btn btn-danger fa fa-times"> Cancel</i></a>
                <h1 class="page-subhead-line"></h1>
            </div>
        </div>
        <!-- /. ROW  -->
        <div class="row">
            <div class="c col-sm-12 ">
                <div class="panel panel-info">
                    <div class="panel-heading">
                        Trip edit
                    </div>
                    <div class="panel-body">
                        <?php
                        $sc = new dalTrip();
                        $sc->Id = $_GET['id'];
                        $data = $sc->edit();
                        ?>
                        <form role="form" method="post" action="master.php?o=trip-update" enctype="multipart/form-data">
                            <input  type="hidden" name="id" value="<?php echo $data->id; ?>">
                            <div class="form-group">
                                <label>ambulance no</label>
                                <select  class="form-control" name="ambid" value="<?php echo $data->ambulance; ?>">
                                    <?php
                                    $t = new dalAmbulance();
                                    Dropdown($t->GlobalView("ambulance", "id, vehicle_no name", "vehicle_no desc"), 0);
                                    ?>

                                </select>
                                <p class="help-block">Help text here.</p>
                            </div>
                            <div class="form-group">
                                <label>Staff Name</label>
                                 <select name="driver" class="form-control" value="<?php echo $data->staffid; ?>">
                                  <?php 
                                   $t = new dalStaff();
                                   Dropdown($t->GlobalView("staff", "id, name", "name desc"), 0);
                                    ?>

                                </select>
                                <p class="help-block">Help text here.</p>
                            </div>
                            <div class="form-group">
                                <label>start_destination</label>
                                <input class="form-control" type="text" name="sdestination" value="<?php echo $data->start_destination; ?>">
                                <p class="help-block">Help text here.</p>
                            </div>
                            <div class="form-group">
                                <label>end_destination</label>
                                <input class="form-control" type="text" name="edestination" value="<?php echo $data->end_destination; ?>">
                                <p class="help-block">Help text here.</p>
                            </div>
                            <div class="form-group">
                                <label>amount</label>
                                <input class="form-control" type="text" name="rentamount" value="<?php echo $data->amount; ?>">
                                <p class="help-block">Help text here.</p>
                            </div>
                            <div class="form-group">
                                <label>date</label>
                                <input class="form-control" type="text" name="tripdate" value="<?php echo $data->date; ?>">
                                <p class="help-block">Help text here.</p>
                            </div>
                            <input type="submit" onclick="Update()"  name="sub" value= "Update" class="btn btn-success"/>
<i
                        </form>
                    </div>
                </div>
            </div>

        </div>
        <!--/.ROW-->


    </div>
    <!-- /. PAGE INNER  -->
</div>







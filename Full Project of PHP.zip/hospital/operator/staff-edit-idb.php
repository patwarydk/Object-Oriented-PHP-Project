<div id="page-wrapper">
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
                <h1 class="page-head-line">Staff Information Modify</h1>
                <h1 class="page-subhead-line"></h1>

            </div>
        </div>
        <!-- /. ROW  -->
        <div class="row">
            <div class="c col-sm-12 ">
                <div class="panel panel-info">
                    <div class="panel-heading">
                     Staff Information Modify
                    </div>
                    <div class="panel-body">
                        <?php
                        $st = new dalStaff();
                        $st ->Id = $_GET['id'];
                        $data = $st ->edit();
                        ?>
                        <form role="form" method="post" action="master.php?o=staff-update" enctype="multipart/form-data">
                            <input  type="hidden" name="id" value="<?php echo $data->id; ?>">
                             <div class="form-group">
                                <label>Name</label>
                                 <input class="form-control" type="text" name="name" value="<?php echo $data->name; ?>">
                                <p class="help-block"></p>
                            </div>
                            <div class="form-group">
                                <label>Department</label>
                                <select name="departmentid" class="form-control">
                                    <?PHP
                                    $v = new dalDepartment();
                                    Dropdown( $v->GlobalView("department", "id,name", "name asc"),0);
                                   
                                    ?>
                                </select>
                                <p class="help-block"></p>
                            </div>
                            <div class="form-group">
                                <label>Designation</label>
                                <select name="designationid" class="form-control">
                                    <?PHP
                                    $v = new dalDesignation();
                                    Dropdown( $v->GlobalView("designation", "id,name", "name asc"),0);
                                   
                                    ?>
                                </select>
                                <p class="help-block"></p>
                            </div>
                            <div class="form-group">
                                <label>Salary</label>
                                <input class="form-control" type="text" name="salary" value="<?php echo $data->salary; ?>">
                                <p class="help-block"></p>
                            </div>
                            <div class="form-group">
                                <label>Contact</label>
                                <input class="form-control" type="text" name="cont" value="<?php echo $data->contact; ?>">
                                <p class="help-block"></p>
                            </div>
                            <div class="form-group">
                                <label>Gender</label><br/>
                                <input type="radio" name="gen" value="1">Male<br/>
                                <input type="radio" name="gen" value="2">Female<br/>
                                <input type="radio" name="gen" value="3">Others<br/>
                                <p class="help-block"></p>
                            </div>
                            <div class="form-group">
                                <label>Address</label>
                                <input class="form-control" type="text" name="addr" value="<?php echo $data->address; ?>">
                                <p class="help-block"></p>
                            </div>
                            <div class="form-group">
                                <label>Age</label>
                                <input class="form-control" type="text" name="age" value="<?php echo $data->age; ?>">
                                <p class="help-block"></p>
                            </div>
                            <div class="form-group">
                                <label>Picture</label>
                                <input class="form-control" type="file" name="pic" value="<?php echo $data->picture; ?>">
                                 <td><img style='width:100px; height:80px;' src="<?php echo 'images/staff/staff-'.$data->id.".".$data->picture; ?>"/></td>
                                <p class="help-block"></p>
                            </div>
                           
                            <input type="submit"  name="sub" value= "Update" class="btn btn-success"/>
                        </form>
                    </div>
                </div>
            </div>

        </div>
        <!--/.ROW-->


    </div>
    <!-- /. PAGE INNER  -->
</div>







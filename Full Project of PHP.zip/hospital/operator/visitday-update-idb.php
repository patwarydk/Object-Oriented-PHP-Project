<?php

if(isset($_POST['sub'])){
  $v = new dalVisitday();
   $v->Id = $_POST['id'];
  $v->Doctorid = $_POST['doctorid'];
  $v->Day = $_POST['day'];
  
  if($v->update()){
      Redirect("master.php?o=visitday-new&msg=Update Successful");
      
  }
  else{
      Redirect("master.php?o=visitday-new&msg=Not Save");
  }
}
else{
    Redirect("master.php?o=visitday-new");
}


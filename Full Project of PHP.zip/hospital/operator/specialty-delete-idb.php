<?php

if(isset($_GET['id'])){
  $sc = new dalSpecialty();
  $sc->Id = $_GET['id'];
 
  if($sc->delete()){
      
      
      Redirect("master.php?o=specialty-view&msg=Delete Successful");
      
  }
  else{
     
     Redirect("master.php?o=specialty-view&msg=other data dependet");
  }
}
else{
   // Redirect("master.php?o=Subcategory-veiw");
}




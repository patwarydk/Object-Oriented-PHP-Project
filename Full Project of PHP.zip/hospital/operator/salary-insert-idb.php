<?php

if (isset($_POST['sub'])) {
    $sal = new dalSalary();
    $sal->Details = $_POST['dtl'];
    $sal->Date = date("Y-m-d");
    $sal->Userid = $_SESSION['myid'];

    $nam = $_POST['id'];
    $amu = $_POST['amu'];
    
    $totalAmount = 0;

     for ($i = 0; $i < count($nam); $i++) {
        if ($nam[$i] > 0) {
            $sal->Name = $nam[$i];
            $sal->Amount = $amu[$i];
            $sal->save();
            
            $totalAmount += Calc($amu[$i]);
        }
    }
    $cash = new dalCash();
    $cash->Accounthead = "Salary Account";
    $cash->Debit = '00,00,000';
    $cash->Credit = $totalAmount;
    $cash->Remarks = "Salary paid to staff";
    $cash->Date = date("Y-m-d");
    $cash->insert();
    
   Redirect("master.php?o=salary&msg=Save Successfull");
} else {
   Redirect("master.php?o=salary");
}
/*



<?php

if (isset($_POST['sub'])) {
    $sal = new dalSalary();
    $sal->Name = $_POST['nam'];
    $sal->Amount = $_POST['amu'];
    $sal->Details = $_POST['dtl'];
    $sal->Date = date("Y-m-d");
    $sal->Userid = $_SESSION['myid'];
    
 // $totalAmount = 0;

    for ($i = 0; $i < count($salary); $i++) {
        if ($salary[$i] > 0) {
            $di->Name = $salary[$i];
            $di->Amount = $amount[$i];
            $di->Details = $dtl[$i];
            $di->save();

            //$totalAmount += Calc($amount[$i]);
        }
    }

    $cash = new dalCash();
    $cash->Accounthead = "Diagonostic Test";
    $cash->Debit = $totalAmount;
    $cash->Credit = $totalAmount;
    $cash->Remarks = "Diagonostic Test";
    $cash->Date = date("Y-m-d");
    $cash->insert();

   // Redirect("master.php?o=salary&msg=Save Successfull");
} else {
   // Redirect("master.php?o=salary&msg=Not Save");
}
*/
<?php

if(isset($_GET['id'])){
  $v = new dalVisitday();
  $v->Id = $_GET['id'];
 
  if($v->delete()){
      
      
      Redirect("master.php?o=visitday-view&msg=Delete Successful");
      
  }
  else{
     
     Redirect("master.php?o=visitday-view&msg=other data dependet");
  }
}
else{
   // Redirect("master.php?o=Subcategory-veiw");
}







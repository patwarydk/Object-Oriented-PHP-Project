<?php

if(isset($_POST['sub'])){
    $trip= new dalTrip();
    $trip->Ambulanceno =$_POST['ambid'];
    $trip->Driver =$_POST['driver'];
    $trip->Sdestination =$_POST['sdestination'];
    $trip->Edestination =$_POST['edestination'];
    $trip->Amount=$_POST['rentamount'];
    $trip->Tripdate =$_POST['tripdate'];
    
    if($trip->insert()){
        $cash = new dalCash();
        $cash->Accounthead='Trip Rent';
        $cash->Debit=['00'];
        $cash->Credit=$_POST['rentamount'];
        $cash->Remarks ='Trip Rent';
        $cash->Date=$_POST['tripdate'];
        $cash->insert();
        Redirect("master.php?o=trip-new&msg=Save Successful");
    }else{
    //   echo $trip->Err;
      Redirect("master.php?o=trip-new&msg=Not Save");  
    }
}
else{
    Redirect("master.php?o=trip-new");
}
?>

<div id="page-wrapper">
    <div id="page-inner" class=" modal-content">
        <div class="row">
            <div class="col-md-12">
                <h1 class="page-head-line">Staff Profile Information</h1>
                <h1 class="page-subhead-line"></h1>

            </div>
        </div>
        <!-- /. ROW  -->
        <div class="row">
            <div class="c col-sm-12 ">
                <div class="panel panel-info">
                    <div class="panel-heading">
                      Staff
                    </div>
                    <div class="panel-body">
                        <form role="form" method="post" action="master.php?o=staff-insert" enctype="multipart/form-data">
                            <div class="form-group">
                                <label>Name</label>
                                <input class="form-control" type="text" name="name">
                                <p class="help-block"></p>
                            </div>
                            <div class="form-group">
                                <label>Department</label>
                                <select name="departmentid" class="form-control">
                                    <?PHP
                                    $v = new dalDepartment();
                                    Dropdown( $v->GlobalView("department", "id,name", "name asc"),0);
                                   
                                    ?>
                                </select>
                                <p class="help-block"></p>
                            </div>
                            <div class="form-group">
                                <label>Designation</label>
                                <select name="designationid" class="form-control">
                                    <?PHP
                                    $v = new dalDesignation();
                                    Dropdown( $v->GlobalView("designation", "id,name", "name asc"),0);
                                   
                                    ?>
                                </select>
                                <p class="help-block"></p>
                            </div>
                            <div class="form-group">
                                <label>Salary</label>
                                <input class="form-control" type="text" name="salary">
                                <p class="help-block"></p>
                            </div>
                            <div class="form-group">
                                <label>Contact</label>
                                <input class="form-control" type="text" name="cont">
                                <p class="help-block"></p>
                            </div>
                            <div class="form-group">
                                <label>Gender</label><br/>
                                <input type="radio" name="gen" value="M">Male<br/>
                                <input type="radio" name="gen" value="F">Female<br/>
                                <input type="radio" name="gen" value="O">Others<br/>
                                <p class="help-block"></p>
                            </div>
                            <div class="form-group">
                                <label>Address</label>
                                <input class="form-control" type="text" name="addr">
                                <p class="help-block"></p>
                            </div>
                            <div class="form-group">
                                <label>Age</label>
                                <input class="form-control" type="text" name="age">
                                <p class="help-block"></p>
                            </div>
                            <div class="form-group">
                                <label>Picture</label>
                                <input class="form-control" type="file" name="pic">
                                <p class="help-block"></p>
                            </div>
                           
                            <input type="submit"  name="sub" value= "Save" class="btn btn-success"/>
<i
                        </form>
                    </div>
                </div>
            </div>

        </div>
        <!--/.ROW-->


    </div>
    <!-- /. PAGE INNER  -->
</div>






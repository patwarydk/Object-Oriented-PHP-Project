<?php

if(isset($_GET['id'])){
  $sc = new dalSubCategory();
  $sc->Id = $_GET['id'];
 
  if($sc->delete()){
      
      
      Redirect("master.php?o=Subcategory-veiw&msg=Delete Successful");
      
  }
  else{
     
     Redirect("master.php?o=Subcategory-veiw&msg=other data dependet");
  }
}
else{
   // Redirect("master.php?o=Subcategory-veiw");
}




<?php

if(isset($_GET['id'])){
  $sc = new dalStaff();
  $sc->Id = $_GET['id'];
 
  if($sc->delete()){
      
      
      Redirect("master.php?o=staff-view&msg=Delete Successful");
      
  }
  else{
     
     Redirect("master.php?o=staff-view&msg=other data dependet");
  }
}
else{
   Redirect("master.php?o=staff-veiw");
}




<?php

if(isset($_POST['sub'])){
  $st = new dalStaff();
  $st->Id = $_POST['id'];
  $st->Name = $_POST['name'];
  $st->Department = $_POST['departmentid'];
  $st->Designation = $_POST['designationid'];
  $st->Salary = $_POST['salary'];
  $st->Contact = $_POST['cont'];
  $st->Gender = $_POST['gen'];
  $st->Address = $_POST['addr'];
  $st->Age = $_POST['age'];

  if($st->update()){
      Redirect("master.php?o=staff-view&msg=Update Successful");
      
  }
  else{
      Redirect("master.php?o=staff-view&msg=Not Save");
  }
}
else{
    Redirect("master.php?o=staff-new");
}



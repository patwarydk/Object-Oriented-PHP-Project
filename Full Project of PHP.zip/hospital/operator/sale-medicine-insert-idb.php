<?php

if (isset($_POST['sub'])) {
    $sm = new dalSaleMedicine();
    $medId = $_POST['medicineid'];
    $qty = $_POST['qty'];
    $total = $_POST['total'];
    $sm->PatientId = $_POST['ptn'];
    $sm->Date = date('Y-m-d h:i:s');


    for ($i = 0; $i < count($medId); $i++) {
        if ($medId[$i] > 0 && $qty[$i] > 0) {
            $sm->MedicineId = $medId[$i];
            $sm->Quantity = $qty[$i];
            $sm->Total = $total[$i];
            $total = $sm->Total;
            $sm->save();
        }
    }
    $cash = new dalCash();
    $cash->Accounthead = "Sale Madicine";
    $cash->Debit = 0;
    $cash->Credit = $total;
    $cash->Remarks = "paid";
    $cash->Date = date("Y-m-d");
    $cash->insert();
    Redirect("master.php?o=sale-medicine&msg=Save Successfull");
} else {
    Redirect("master.php?o=sale-medicine&msg=Not Save");
}

<link rel="stylesheet" type="text/css" href="assets/css/jquery.tokenize.css" />

<script type="text/javascript" src="assets/js/jquery.js"></script>
<script type="text/javascript" src="assets/js/jquery-ui.min.js"></script>
<script type="text/javascript" src="assets/js/jquery.tokenize.js"></script>
<div id="page-wrapper">
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
                <h1 class="page-head-line">Doctor Information</h1>
                <a href="master.php?o=visitday-New"><i class="btn btn-success fa fa-file"> New visit day</i></a>
                <a href="master.php?o=visitday-view"><i class="btn btn-success fa fa-file"> View</i></a>
                <a href="master.php"><i onclick="Cancel()" class="btn btn-danger fa fa-times"> Cancel</i></a>
                <h1 class="page-subhead-line"></h1>
            </div>
        </div>
        <!-- /. ROW  -->
        <div class="row">
            <div class="col-md-10 col-sm-10 col-xs-12">
                <div class="panel panel-info">
                    <div class="panel-heading">
                        Add New Doctor Entry FORM
                    </div>
                    <div class="panel-body">
                        <?php
                        $v = new dalVisitday();
                        $v->Id = $_GET['id'];
                        $data = $v->edit();
                        ?>
                        <form role="form" action="master.php?o=visitday-update" method="post" >
                            <input  type="hidden" name="id" value="<?php echo $data->id; ?>">
                            <div class="form-group">
                                <label>Choose Doctor</label>

                                <select name="doctorid[]" class="form-control">
                                    <?PHP
                                    $v = new dalDoctor();
                                    Dropdown($v->GlobalView("doctor", "id,name", "name asc"), 0);
                                    ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label>Visiting Available Day</label>
                                <select id="tokenize_day" name="day[]" class="tokenize-sample" multiple="multiple" class="malta form-control">
                                    <option value="Sunday">Sunday</option>
                                    <option value="Monday">Monday</option>
                                    <option value="Tuesday">Tuesday</option>
                                    <option value="Wednesday">Wednesday </option>
                                    <option value="Thursday">Thursday</option>
                                    <option value="Friday">Friday</option>
                                    <option value="Saturday">Saturday</option>
                                </select> 
                            </div>
                            <input type="submit" value="Update" name="sub" class="btn btn-success">
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <script type="text/javascript">
            $('select#tokenize_spe, select#tokenize_day').tokenize({displayDropdownOnFocus: true});
        </script>




<?php
if(isset($_POST['sub'])){
   $sc = new dalRoom();
   $sc->Id = $_POST['id'];
   $sc->Name =$_POST['name'];
   if($sc->update()){
       Redirect("master.php?o=room-view&msg=Update Successfull");
   }
 else {
       Redirect("master.php?o=room-view&msg= Not Update");
   }
}
 else {
     //Redirect("master.php?o=room-view");
}


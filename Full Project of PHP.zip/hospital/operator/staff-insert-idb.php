<?php

if(isset($_POST['sub'])){
  $st = new dalStaff();
  $st->Name = $_POST['name'];
  $st->Department = $_POST['departmentid'];
  $st->Designation = $_POST['designationid'];
  $st->Salary = $_POST['salary'];
  $st->Contact = $_POST['cont'];
  $st->Gender = $_POST['gen'];
  $st->Address = $_POST['addr'];
  $st->Age = $_POST['age'];
   if ($_FILES['pic']['name'] != "") {
        $ext = pathinfo($_FILES['pic']['name']);
        $ext = strtolower($ext['extension']);

        if ($ext != "jpg" && $ext != "png" && $ext != "gif" && $ext != "jpeg") {
            $st->Picture = "";
        } else {
            $st->Picture = $ext;
        }
    } else {
        $st->Picture = "";
    }
  if($st->insert()){
	   $id = $st->Id;
        if ($ext != "") {
            move_uploaded_file($_FILES['pic']['tmp_name'], "images/staff/staff-{$id}.{$ext}");
        }
      Redirect("master.php?o=staff-new&msg=Save Successful");
      
  }
  else{
      Redirect("master.php?o=staff-new&msg=Not Save");
  }
}
else{
    Redirect("master.php?o=staff-new");
}


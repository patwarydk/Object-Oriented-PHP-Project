<div id="page-wrapper">
    <div id="page-inner">
        <div class="row">
            <div class="col-md-12">
                <h1 class="page-head-line">SubCategory-new</h1>
                <h1 class="page-subhead-line">This is dummy text , you can replace it with your original text. </h1>

            </div>
        </div>
        <!-- /. ROW  -->
        <div class="row">
            <div class="c col-sm-12 ">
                <div class="panel panel-info">
                    <div class="panel-heading">
                        Sub Category
                    </div>
                    <div class="panel-body">
                        <form role="form" method="post" action="master.php?o=subcategory-insert">
                            <div class="form-group">
                                <label>Name</label>
                                <input class="form-control" type="text" name="name">
                                <p class="help-block">Help text here.</p>
                            </div>
                            <div class="form-group">
                                <label>Chose Category</label>

                                <select name="catid" class="form-control">
                                    <?PHP
                                    $c = new dalCategory();
                                    Dropdown( $c->view(),0);
                                   
                                    ?>
                                </select>
                            </div>



                            <input type="submit"  name="sub" value= "Save" class="btn btn-success"/>
<i
                        </form>
                    </div>
                </div>
            </div>

        </div>
        <!--/.ROW-->


    </div>
    <!-- /. PAGE INNER  -->
</div>






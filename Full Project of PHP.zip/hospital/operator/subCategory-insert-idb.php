<?php

if(isset($_POST['sub'])){
  $sc = new dalSubCategory();
  $sc->Name = $_POST['name'];
  $sc->Categoryid = $_POST['catid'];
  if($sc->insert()){
      Redirect("master.php?o=Subcategory-new&msg=Save Successful");
      
  }
  else{
      Redirect("master.php?o=Subcategory-new&msg=Not Save");
  }
}
else{
    Redirect("master.php?o=Subcategory-new");
}


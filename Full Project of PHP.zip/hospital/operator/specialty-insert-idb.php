<?php

if(isset($_POST['sub'])){
  $sc = new dalSpecialty();
  $sc->Name = $_POST['name'];
  if($sc->insert()){
      Redirect("master.php?o=specialty-new&msg=Save Successful");
      
  }
  else{
      Redirect("master.php?o=specialty-new&msg=Not Save");
  }
}
else{
    Redirect("master.php?o=specialty-new");
}


<?php

if(isset($_POST['sub'])){
  $sc = new dalTrip();
  $sc->Id = $_POST['id'];
  $sc->Ambulanceno = $_POST['ambid'];
  $sc->Driver = $_POST['driver'];
  $sc->Sdestination = $_POST['sdestination'];
  $sc->Edestination = $_POST['edestination'];
  $sc->Amount = $_POST['rentamount'];
  $sc->Tripdate = $_POST['tripdate'];
  if($sc->update()){
      Redirect("master.php?o=trip-view&msg=Update Successful");
      
  }
  else{
      Redirect("master.php?o=trip-view&msg=Not Save");
  }
}
else{
    Redirect("master.php?o=trip-new");
}



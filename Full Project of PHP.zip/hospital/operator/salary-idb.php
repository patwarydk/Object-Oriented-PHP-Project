<title>IDB Hospital | Salary</title>
<?php
$_SESSION['myid'];
?>
<div id="page-wrapper">
    <div id="page-inner" class="modal-content">
        <div class="row">
            <div class="col-sm-12">
                <h1 class="page-head-line">Salary Sheet</h1>
                <a href="master.php?o=salary-view"><i class="btn btn-success fa fa-file"> View</i></a>
                <a href="master.php"><i onclick="Cancel()" class="btn btn-danger fa fa-times"> Cancel</i></a>
                <h1 class="page-subhead-line"></h1>
            </div>
        </div>
        <!-- /. ROW  -->
        <div class="row">
            <div class="c col-md-8 col-md-offset-2 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1">
                <div class="panel panel-info modal-content">
                    <div class="panel-heading">
                        <h4>Create Salary Sheet month of :  <?php echo date('M - Y'); ?></h4> 
                    </div>
                    <div class="panel-body">
                        <form role="form" action="master.php?o=salary-insert" method="post">
                            <table class="table table-striped table-responsive table-hover">
                                <tr class="form-group">
                                    <th align="center">Identity</th>
                                    <th>Staff Name</th>
                                    <th>Due Salary</th>
                                    <th>Advance Salary</th>
                                    <th>Salary</th>
                                </tr>

                                <?php
                                $sal = new dalStaff();
                                $data = $sal->GlobalView("staff", "id, name, salary", "id asc");
                                foreach ($data as $dt) {
                                    echo "<tr>";
                                    echo "<td name='nam[]' value=\"{$dt->id}\" >{$dt->id}</td>";
                                    echo"<td>{$dt->name}</td>";
                                    ?>
                                    <td>
                                        <input type="hidden" name="id[]" value="<?php echo $dt->id ?>" />
                                        <input class="form-control" type="text" value="<?php echo $dt->salary ?>" />
                                    </td>
                                    <td><input class="form-control" type="text"/></td>
                                    <td><input class="form-control" type="text" name="amu[]" value="<?php echo $dt->salary ?>"/></td>
                                    <?php
                                }
                                ?>
                                </tr>
                            </table>
                            <div>
                                <label>Description</label>
                                <textarea class="form-control" name="dtl"></textarea>
                            </div><br>
                            <div class="confirm">
                                <button onclick="Save()" name="sub" class="btn btn-success btn-sm">Save</button>
                                <input onclick="Reset()" type="reset" name="cancel" value="Reset" class="btn btn-danger btn-sm"/>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php

if(isset($_POST['sub'])){
  $sc = new dalSubCategory();
  $sc->Id = $_POST['id'];
  $sc->Name = $_POST['name'];
  $sc->Categoryid = $_POST['catid'];
  if($sc->insert()){
      Redirect("master.php?o=Subcategory-veiw&msg=Update Successful");
      
  }
  else{
      Redirect("master.php?o=Subcategory-veiw&msg=Not Save");
  }
}
else{
    Redirect("master.php?o=Subcategory-new");
}



<?php

if(isset($_GET['id'])){
  $sc = new dalTrip();
  $sc->Id = $_GET['id'];
 
  if($sc->delete()){
      
      
      Redirect("master.php?o=trip-view&msg=Delete Successful");
      
  }
  else{
     
     Redirect("master.php?o=trip-view&msg=other data dependend");
  }
}
else{
   // Redirect("master.php?o=Subcategory-veiw");
}




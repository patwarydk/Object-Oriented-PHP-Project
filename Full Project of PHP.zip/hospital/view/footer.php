<section>
    <div class="row">
        <div class="col-sm-12">
            <div id="footer-sec">
                &copy; 2014 YourCompany | Design By : <a href="http://www.binarytheme.com/" target="_blank">BinaryTheme.com</a>
           </div>
        </div>
    </div>
</section>